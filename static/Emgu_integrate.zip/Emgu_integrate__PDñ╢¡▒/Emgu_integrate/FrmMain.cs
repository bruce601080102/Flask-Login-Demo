﻿using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;
using Emgu_integrate;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace _Emgu_integrate
{
    public partial class FrmMain : Form
    {
        List<string> path = new List<string>();

        Point imgSourcePoint;
        Point imgSelectPoint;
        Point point6;
        Point point7;

        Image<Bgr, byte> imgInput = null;
        Image<Gray, byte> imgGray = null;
        
        Image<Gray, byte> imgOutput = null;
        Image<Gray, byte> imgOutput2 = null;

        List<double> VT = new List<double>(); //腦組織
        List<double> VP = new List<double>(); //腦實質

        List<double> CD_N_PU_TR = new List<double>();
        List<double> CD_N_PU_TL = new List<double>();
        List<double> STN = new List<double>();
        List<double> OC_B = new List<double>();

        List<double> VTS = new List<double>();

        int num1 = 0;
        int count = 1;

        double VS = 0; //全腦組織面積
        double VPP;

        double VTTR;
        double VTTL;

        double SUR_1;
        double SUR_2;
        double SUR_3;
        double SUR_4;

        double test1;
        double test2;
        double test3;
        double test4;
        double test5;
        double test8;
        double test9;
        double test10;
        double test11;
        double test66;

        double ASI1;

        double VolCN; //尾狀核體積
        double VolPM; //殼核體積
        double VolOB; //枕骨體積
        double VolSN; //黑質體積

        Rectangle Rect = new Rectangle();
        Rectangle RealImageRect = new Rectangle();

        Brush selectionBrush = new SolidBrush(Color.FromArgb(128, 64, 64, 64));

        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnDialog_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "文字檔案(*.txt)|*.txt";
            if (openFileDialog.ShowDialog() == DialogResult.OK)    
            {
                txtFilePath.Text = openFileDialog.FileName;

                StreamReader streamReader = new StreamReader(txtFilePath.Text);

                txtRecordNo.Text = streamReader.ReadLine();
                txtIdNo.Text = streamReader.ReadLine();
                txtAge.Text = streamReader.ReadLine();

                streamReader.Close();
            }
            else
            {
                MessageBox.Show("請開啟病歷資料txt檔案");
            }
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            tclMain.SelectedIndex = 1;
        }

        private void monthCalendar1_DateSelected(object sender, DateRangeEventArgs e)
        {
            txtMedicalDate.Text = monthCalendar1.SelectionStart.ToString("yyyy/MM/dd");
        }

        private void btnInputOK_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtFilePath.Text))
            {
                StreamWriter streamWriter = new StreamWriter(txtFilePath.Text);
                streamWriter.WriteLine(txtRecordNo.Text);
                streamWriter.WriteLine(txtIdNo.Text);
                streamWriter.WriteLine(txtAge.Text);

                streamWriter.Close();
            }
            else
            {
                MessageBox.Show("請設定病歷資料txt檔案");
            }
        }

        private void btnInputClear_Click(object sender, EventArgs e)
        {
            txtFilePath.Text = "";
            txtRecordNo.Text = "";
            txtIdNo.Text = "";
            txtMedicalDate.Text = "";

            for(int i = 0; i < clxSex.Items.Count; i++)
            {
                clxSex.SetItemChecked(i, false);
            }

            txtAge.Text = "";
        }

        private void btnLoadImage_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                imgInput = new Image<Bgr, byte>(openFileDialog.FileName);
                imgSource.Image = imgInput;
            }
            else
            {
                MessageBox.Show("請開啟影像檔案");
            }
        }

        private void btnLoadFolder_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDlg = new FolderBrowserDialog();
            DialogResult dlgResult = folderBrowserDlg.ShowDialog();

            path.Clear();

            if (folderBrowserDlg.ShowDialog() == DialogResult.OK)
            {
                string[] allowedExtensions = new[] { ".jpg", ".png", ".bmp" };
                foreach (string file in Directory.GetFiles(folderBrowserDlg.SelectedPath).Where(file => allowedExtensions.Any(file.ToLower().EndsWith)))
                {
                    path.Add(file);
                }

                path.Sort((a, b) => new StringNum(a).CompareTo(new StringNum(b)));

                nudImage.Maximum = path.Count();
                try
                {
                    imgInput = new Image<Bgr, byte>(path[(int)nudImage.Value - 1]);
                    imgSource.Image = imgInput;
                }
                catch (Exception)
                {
                    MessageBox.Show("資料夾內無符合格式影像");
                }
            }
        }

        private void imgSource_MouseDown(object sender, MouseEventArgs e)
        {
            imgSourcePoint = e.Location;
            Invalidate();
        }

        private void nudImage_ValueChanged(object sender, EventArgs e)
        {
            nudImage.Maximum = path.Count();
            try
            {
                imgSource.Image = new Image<Bgr, byte>(path[(int)nudImage.Value - 1]);
            }
            catch
            {
                //MessageBox.Show("資料夾內無符合格式影像");
            }
        }

        private void btnHead_Click(object sender, EventArgs e)
        {
            Image<Gray, byte> image_Copy = imgInput.Convert<Gray, byte>();
            Image<Gray, byte> mask = new Image<Gray, byte>(imgInput.Width + 2, imgInput.Height + 2);
            Image<Gray, byte> imgasd;

            Rectangle dummy = new Rectangle(0, 0, 0, 0);
            CvInvoke.FloodFill(image_Copy, mask, imgSourcePoint, new MCvScalar(1), out dummy,
                new MCvScalar(12),
                new MCvScalar(7),
                Emgu.CV.CvEnum.Connectivity.EightConnected,
                Emgu.CV.CvEnum.FloodFillType.Default);
            imgasd = (imgInput.Convert<Gray, byte>()) - image_Copy;

            imgPorcess.Image = imgasd;

            imgOutput = imgasd;
        }

        private void btnCutMiddle_Click(object sender, EventArgs e)
        {
            if (imgOutput != null)
            {
                Image<Gray, byte> imgBgr = imgOutput;
                Image<Gray, byte> median = new Image<Gray, byte>(imgOutput.Width, imgOutput.Height, new Gray(0));
                Image<Gray, byte> blur = new Image<Gray, byte>(imgOutput.Width, imgOutput.Height, new Gray(0));
                median = imgBgr.SmoothMedian((int)nudCutMiddle.Value);
                //blur = median.SmoothBlur(3, 3);
                blur = median.Copy();

                imgOutput = blur.Copy();
                imgOutput2 = blur.Copy();
                //imgOutput3 = blur.Copy();

                imgPorcess.Image = imgOutput;
                imgSelect.Image = imgOutput2;
            }
        }

        private void btnCT_Click(object sender, EventArgs e)
        {
            Image<Gray, byte> imgray = imgOutput.ThresholdBinary(new Gray(25), new Gray(255));
            Image<Gray, byte> imgray2 = imgOutput.ThresholdBinary(new Gray((int)nudCutMiddle1.Value), new Gray(255));
            
            int area = 0;
            for (int i = 0; i < imgray.Rows; i++)
            {
                for (int j = 0; j < imgray.Cols; j++)
                {
                    if (imgray.Data[i, j, 0] == 255)
                        area++;

                }
            }
            
            int area1 = 0;
            for (int i = 0; i < imgray2.Rows; i++)
            {
                for (int j = 0; j < imgray2.Cols; j++)
                {
                    if (imgray2.Data[i, j, 0] == 255)
                        area1++;

                }
            }
            
            double AT = Convert.ToDouble(area) * 0.2304;
            double AV = Convert.ToDouble(area1) * 0.2304;

            listBox15.Items.Add(AT.ToString("f4"));
            listBox16.Items.Add(AV.ToString("f4"));
            VT.Add(AT);
            VP.Add(AV);
        }

        private void btnMRI_Click(object sender, EventArgs e)
        {
            Image<Gray, byte> imgray = imgOutput.ThresholdBinary(new Gray(25), new Gray(255));
            Image<Gray, byte> imgray2 = imgOutput.ThresholdBinary(new Gray((int)nudCutMiddle1.Value), new Gray(255));
            
            int area = 0;
            for (int i = 0; i < imgray.Rows; i++)
            {
                for (int j = 0; j < imgray.Cols; j++)
                {
                    if (imgray.Data[i, j, 0] == 255)
                        area++;

                }
            }

            int area1 = 0;
            for (int i = 0; i < imgray2.Rows; i++)
            {
                for (int j = 0; j < imgray2.Cols; j++)
                {
                    if (imgray2.Data[i, j, 0] == 255)
                        area1++;

                }
            }

            double AT = Convert.ToDouble(area) * 0.1936;
            double AV = Convert.ToDouble(area1) * 0.1936;
            listBox15.Items.Add(AT.ToString("f4"));
            listBox16.Items.Add(AV.ToString("f4"));
            VT.Add(AT);
            VP.Add(AV);
        }

        private void btnSPECT_Click(object sender, EventArgs e)
        {
            Image<Gray, byte> imgray = imgOutput.ThresholdBinary(new Gray(25), new Gray(255));
            Image<Gray, byte> imgray2 = imgOutput.ThresholdBinary(new Gray((int)nudCutMiddle1.Value), new Gray(255));

            int area = 0;
            for (int i = 0; i < imgray.Rows; i++)
            {
                for (int j = 0; j < imgray.Cols; j++)
                {
                    if (imgray.Data[i, j, 0] == 255)
                        area++;

                }
            }

            int area1 = 0;
            for (int i = 0; i < imgray2.Rows; i++)
            {
                for (int j = 0; j < imgray2.Cols; j++)
                {
                    if (imgray2.Data[i, j, 0] == 255)
                        area1++;

                }
            }

            double AT = Convert.ToDouble(area) * 0.1521;
            double AV = Convert.ToDouble(area1) * 0.1521;
            listBox15.Items.Add(AT.ToString("f4"));
            listBox16.Items.Add(AV.ToString("f4"));
            VT.Add(AT);
            VP.Add(AV);
        }

        private void btnNextImage_Click(object sender, EventArgs e)
        {
            nudImage.Maximum = path.Count();
            if (nudImage.Value < path.Count())
            {
                nudImage.Value = nudImage.Value + 1;
            }
        }

        private void imgSelect_Paint(object sender, PaintEventArgs e)
        {
            if (chkROI.Checked && imgSelect.Image != null)
            {
                if (Rect != null && Rect.Width > 0 && Rect.Height > 0)
                {
                    //Seleciona a ROI
                    e.Graphics.SetClip(Rect, System.Drawing.Drawing2D.CombineMode.Exclude);
                    e.Graphics.FillRectangle(selectionBrush, new Rectangle(0, 0, ((PictureBox)sender).Width, ((PictureBox)sender).Height));
                    //e.Graphics.FillRectangle(selectionBrush, Rect);
                }
            }
        }

        private void imgSelect_MouseDown(object sender, MouseEventArgs e)
        {
            imgSelectPoint = e.Location;
            Invalidate();
        }

        private void imgSelect_MouseMove(object sender, MouseEventArgs e)
        {
            Utilities.ConvertCoordinates(imgSelect, out int X0, out int Y0, e.X, e.Y);
            label1.Text = "Last Position: X:" + X0 + "  Y:" + Y0;

            if (chkROI.Checked)
            {
                //Coordinates at input picture box
                if (e.Button != MouseButtons.Left)
                    return;
                Point tempEndPoint = e.Location;
                Rect.Location = new Point(
                    Math.Min(imgSelectPoint.X, tempEndPoint.X),
                    Math.Min(imgSelectPoint.Y, tempEndPoint.Y));
                Rect.Size = new Size(
                    Math.Abs(imgSelectPoint.X - tempEndPoint.X),
                    Math.Abs(imgSelectPoint.Y - tempEndPoint.Y));



                //Coordinates at real image - Create ROI
                Utilities.ConvertCoordinates(imgSelect, out X0, out Y0, imgSelectPoint.X, imgSelectPoint.Y);
                Utilities.ConvertCoordinates(imgSelect, out int X1, out int Y1, tempEndPoint.X, tempEndPoint.Y);
                RealImageRect.Location = new Point(
                    Math.Min(X0, X1),
                    Math.Min(Y0, Y1));
                RealImageRect.Size = new Size(
                    Math.Abs(X0 - X1),
                    Math.Abs(Y0 - Y1));
                ((PictureBox)sender).Invalidate();
            }
        }

        private void imgSelect_MouseUp(object sender, MouseEventArgs e)
        {
            if (chkROI.Checked && imgOutput2 != null)
            {
                //Define ROI. Valida altura e largura para evitar index range exception.
                if (RealImageRect.Width > 0 && RealImageRect.Height > 0)
                {
                    imgOutput2.ROI = RealImageRect;
                    imageBox4.Image = imgOutput2;
                }
            }
        }

        private void btnUndo_Click(object sender, EventArgs e)
        {
            imgOutput2 = imgOutput.Copy();
            imgSelect.Image = imgOutput2;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (chkROI.Checked != true)
            {
                Image<Gray, byte> image_copy2 = imgOutput2.Copy();
                Image<Gray, byte> mask = new Image<Gray, byte>(imgInput.Width + 2, imgInput.Height + 2);
                Image<Gray, byte> imgasd;
                Rectangle dummy = new System.Drawing.Rectangle(1, 1, 1, 1);
                CvInvoke.FloodFill(image_copy2, mask, imgSelectPoint, new MCvScalar(254), out dummy,
                    new MCvScalar((double)numericUpDown2.Value),
                    new MCvScalar((double)numericUpDown3.Value),
                    Emgu.CV.CvEnum.Connectivity.FourConnected,
                    Emgu.CV.CvEnum.FloodFillType.FixedRange);
                imgasd = image_copy2;
                imgSelect.Image = imgasd;
                imgOutput2 = imgasd.Copy();
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            /*
             1. Edge detection(sobel)
             2. Dilation (10,1)
             3.FindContours
             4.Gemetrical Constrints
             */
            //sobel
            if (imgOutput2 == null)
            {
                return;
            }
            Image<Gray, byte> grayimg = new Image<Gray, byte>(imgOutput2.Bitmap).Resize((1.0), Emgu.CV.CvEnum.Inter.Linear).Dilate(1).PyrUp().PyrDown();
            grayimg = grayimg.ThresholdBinary(new Gray((int)(numericUpDown5.Value)), new Gray(255)); //閥值90適用帕金森氏症基底核分割//依據圈選範圍調整單一侵蝕與膨脹 .Dilate(2)   //90適用帕金森氏症 
            grayimg.SmoothGaussian(13);
            //Mat her = CvInvoke.GetStructuringElement(Emgu.CV.CvEnum.ElementShape.Rectangle, new Size(10, 1), new Point(-1, -1));
            //imgGray = imgGray.MorphologyEx(Emgu.CV.CvEnum.MorphOp.Gradient, her, new Point(-1, -1), 1, Emgu.CV.CvEnum.BorderType.Reflect, new MCvScalar(255));
            VectorOfVectorOfPoint cn = new VectorOfVectorOfPoint();
            VectorOfVectorOfPoint cY = new VectorOfVectorOfPoint();
            //HY1 = 0;
            //HY2 = 0;
            //num = 0;

            Image<Gray, byte> hier = new Image<Gray, byte>(grayimg.Width, grayimg.Height);
            CvInvoke.FindContours(grayimg, cn, hier, Emgu.CV.CvEnum.RetrType.External, Emgu.CV.CvEnum.ChainApproxMethod.ChainApproxSimple);
            CvInvoke.FindContours(grayimg, cY, hier, Emgu.CV.CvEnum.RetrType.List, Emgu.CV.CvEnum.ChainApproxMethod.ChainApproxSimple);

            CvInvoke.DrawContours(imgOutput2, cn, -1, new MCvScalar(0, 0, 190), 1);
            CvInvoke.DrawContours(imgOutput2, cY, -1, new MCvScalar(200, 0, 0), 1);

            Point[][] cons = cn.ToArrayOfArray();
            PointF[][] con2 = Array.ConvertAll<Point[], PointF[]>(cons, new Converter<Point[], PointF[]>(PointToPointF));

            for (int i = 0; i < cn.Size; i++)
            {
                PointF[] hull = CvInvoke.ConvexHull(con2[i], true);
                for (int j = 0; j < hull.Length; j++)
                {
                    Point p1 = new Point((int)(hull[j].X), (int)(hull[j].Y));
                    Point p2;
                    if (j == hull.Length - 1)
                        p2 = new Point((int)(hull[0].X), (int)(hull[0].Y));
                    else
                        p2 = new Point((int)(hull[j + 1].X), (int)(hull[j + 1].Y));
                    //CvInvoke.Circle(imgoutput3, p1, 3, new MCvScalar(0, 255, 255, 255), 0);
                    //CvInvoke.Line(imgoutput3, p1, p2, new MCvScalar(150), 2);


                    double perimeter = CvInvoke.ArcLength(cn[i], true);
                    VectorOfPoint cn2 = new VectorOfPoint();
                    CvInvoke.ApproxPolyDP(cn[i], cn2, 0.02 * perimeter, true);

                    for (int k = 0; k < cY.Size; k++)
                    {
                        double perimeter2 = CvInvoke.ArcLength(cY[k], true);
                        VectorOfPoint cb2 = new VectorOfPoint();
                        CvInvoke.ApproxPolyDP(cY[k], cb2, 0.02 * perimeter2, true);



                        //CvInvoke.FindContours(imgGray, cn, hier, Emgu.CV.CvEnum.RetrType.Ccomp, Emgu.CV.CvEnum.ChainApproxMethod.ChainApproxSimple);

                        //CvInvoke.DrawContours(imgOutput2, cY, k, new MCvScalar(200, 0, 0), 1);
                        CvInvoke.Line(imgOutput2, p1, p2, new MCvScalar(150), 2);
                        //HY1++;
                        //HY2++;
                        //num++;

                    }
                    //imageBox1.Image = imgOutput2;
                    imgSelect.Image = imgOutput2;
                }
            }
        }
        
        public static PointF[] PointToPointF(Point[] pf)
        {
            PointF[] aaa = new PointF[pf.Length];
            int num = 0;
            foreach (var point in pf)
            {
                aaa[num].X = point.X;
                aaa[num++].Y = point.Y;
            }
            return aaa;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (imgOutput2 == null)
            {
                return;
            }

            Image<Gray, byte> grayimg = new Image<Gray, byte>(imgOutput2.Bitmap).Resize((1.0), Emgu.CV.CvEnum.Inter.Linear).Dilate(1).PyrUp().PyrDown();
            grayimg.SmoothGaussian(9);
            grayimg = grayimg.ThresholdBinary(new Gray((int)(numericUpDown8.Value)), new Gray(255)); //閥值90適用帕金森氏症基底核分割
            var element = CvInvoke.GetStructuringElement(ElementShape.Cross, new Size(3, 3), new Point(-1, -1));
            CvInvoke.MorphologyEx(grayimg, grayimg, MorphOp.Erode, element, new Point(-1, -1), 1, BorderType.Reflect, new MCvScalar());
            CvInvoke.MorphologyEx(grayimg, grayimg, MorphOp.Dilate, element, new Point(-1, -1), 1, BorderType.Reflect, new MCvScalar());

            VectorOfVectorOfPoint cn = new VectorOfVectorOfPoint();
            Image<Gray, byte> hier = new Image<Gray, byte>(imgOutput2.Width, imgOutput2.Height);

            //HY1 = 0;
            //HY2 = 0;
            //num1 = 0;

            CvInvoke.FindContours(grayimg, cn, hier, RetrType.Ccomp, ChainApproxMethod.ChainApproxSimple);
            //CvInvoke.FindContours(grayimg, cn, null, RetrType.Ccomp, ChainApproxMethod.ChainApproxNone);

            int count = cn.Size;
            for (int i = 0; i < count; i++)
            {
                using (VectorOfPoint contour = cn[i])
                using (VectorOfPoint approxContour = new VectorOfPoint())
                {
                    // 原始輪廓線
                    CvInvoke.DrawContours(imgOutput2, cn, i, new MCvScalar(170), 1);

                    // 近似後輪廓線
                    CvInvoke.ApproxPolyDP(contour, approxContour, CvInvoke.ArcLength(contour, true) * 0.05, true);
                    Point[][] cons = cn.ToArrayOfArray();
                    PointF[][] con2 = Array.ConvertAll<Point[], PointF[]>(cons, new Converter<Point[], PointF[]>(PointToPointF));
                    PointF[] hull = CvInvoke.ConvexHull(con2[i], true);
                    for (int j = 0; j < hull.Length; j++)
                    {
                        Point p1 = new Point((int)(hull[j].X + 0.5), (int)(hull[j].Y + 0.5));
                        Point p2;
                        if (j == hull.Length - 1)
                            p2 = new Point((int)(hull[0].X + 0.5), (int)(hull[0].Y + 0.5));
                        else
                            p2 = new Point((int)(hull[j + 1].X + 0.5), (int)(hull[j + 1].Y + 0.5));
                        //CvInvoke.Line(imgOutput2, p1, p2, new MCvScalar(150), 2);
                        //CvInvoke.Line(imgOutput2, p1, p2, new MCvScalar(200), 1);
                        //HY1++;
                        //HY2++;
                        //num1++;
                    }
                    //imgOutput2._Not();
                    imgSelect.Image = imgOutput2;
                }
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            CvInvoke.Line(imgOutput2, point6, point7, new MCvScalar(200), 2);
            checkBox2.Checked = false;
            checkBox3.Checked = false;
            imgSelect.Image = imgOutput2;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (checkedListBox2.CheckedItems.Count < 1)
            {
                MessageBox.Show("選擇腦室");
                return;
            }
            if (imgOutput2 == null)
            {
                return;
            }

            Image<Gray, byte> imgray = imgOutput2.ThresholdBinary(new Gray(253), new Gray(255));
            VectorOfVectorOfPoint con = new VectorOfVectorOfPoint();

            double area1 = new double();

            int area = 0;
            for (int i = 0; i < imgOutput2.Rows; i++)
            {
                for (int j = 0; j < imgOutput2.Cols; j++)
                {
                    if (imgray.Data[i, j, 0] == 255)
                        area++;

                }
            }

            area1 = area * 0.2304;
            textBox1.Text = (area1).ToString("f4");

            if (checkedListBox2.GetItemChecked(0))
            {
                CD_N_PU_TR.Add(area1);

                listBox12.Items.Add(area1.ToString("f4"));
            }
            if (checkedListBox2.GetItemChecked(1))
            {
                CD_N_PU_TL.Add(area1);

                listBox4.Items.Add(area1.ToString("f4"));
            }
            if (checkedListBox2.GetItemChecked(2))
            {
                OC_B.Add(area1);
                listBox20.Items.Add(area1.ToString("f4"));
            }

            if (checkedListBox2.GetItemChecked(3))
            {
                STN.Add(area1);
                listBox1.Items.Add(area1.ToString("f4"));
            }

            chkROI.Checked = false;
            for (int i = 0; i < checkedListBox2.Items.Count; i++)
            {
                checkedListBox2.SetItemChecked(i, false);
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            if (checkedListBox2.CheckedItems.Count < 1)
            {
                MessageBox.Show("選擇腦室");
                return;
            }
            if (imgOutput2 == null)
            {
                return;
            }

            Image<Gray, byte> imgray = imgOutput2.ThresholdBinary(new Gray(253), new Gray(255));
            double area1 = new double();
            /*VectorOfVectorOfPoint con = new VectorOfVectorOfPoint();
            double area = new double();
            double area1 = new double();
            Image<Gray, byte> hier = new Image<Gray, byte>(imgoutput2.Width, imgoutput2.Height);
            CvInvoke.FindContours(imgray, con, hier, RetrType.External, ChainApproxMethod.ChainApproxSimple);
            //CvInvoke.DrawContours(imgoutput2, con, -1, new MCvScalar(2));
            //imageBox3.Image = imgoutput2;
            int count = con.Size;
            for (int i = 0; i < count; i++)
            {
                using (VectorOfPoint contour = con[i])
                using (VectorOfPoint approxContour = new VectorOfPoint())
                {
                    area = CvInvoke.ContourArea(contour, false);
                }
            }*/
            int area = 0;
            for (int i = 0; i < imgOutput2.Rows; i++)
            {
                for (int j = 0; j < imgOutput2.Cols; j++)
                {
                    if (imgray.Data[i, j, 0] == 255)
                        area++;
                }
            }

            area1 = area * 0.1936;
            textBox1.Text = area1.ToString("f4");

            if (checkedListBox2.GetItemChecked(0))
            {
                CD_N_PU_TR.Add(area1);

                listBox12.Items.Add(area1.ToString("f4"));
            }
            if (checkedListBox2.GetItemChecked(1))
            {
                CD_N_PU_TL.Add(area1);

                listBox4.Items.Add(area1.ToString("f4"));
            }
            if (checkedListBox2.GetItemChecked(2))
            {
                OC_B.Add(area1);
                listBox20.Items.Add(area1.ToString("f4"));
            }

            if (checkedListBox2.GetItemChecked(3))
            {
                STN.Add(area1);
                listBox1.Items.Add(area1.ToString("f4"));
            }

            chkROI.Checked = false;
            for (int i = 0; i < checkedListBox2.Items.Count; i++)
            {
                checkedListBox2.SetItemChecked(i, false);
            }
        }

        private void button26_Click(object sender, EventArgs e)
        {
            if (checkedListBox2.CheckedItems.Count < 1)
            {
                MessageBox.Show("選擇腦室");
                return;
            }
            if (imgOutput2 == null)
            {
                return;
            }

            Image<Gray, byte> imgray = imgOutput2.ThresholdBinary(new Gray(253), new Gray(255));
            double area1 = new double();
            /*VectorOfVectorOfPoint con = new VectorOfVectorOfPoint();
            double area = new double();
            double area1 = new double();
            Image<Gray, byte> hier = new Image<Gray, byte>(imgoutput2.Width, imgoutput2.Height);
            CvInvoke.FindContours(imgray, con, hier, RetrType.External, ChainApproxMethod.ChainApproxSimple);
            //CvInvoke.DrawContours(imgoutput2, con, -1, new MCvScalar(2));
            //imageBox3.Image = imgoutput2;
            int count = con.Size;
            for (int i = 0; i < count; i++)
            {
                using (VectorOfPoint contour = con[i])
                using (VectorOfPoint approxContour = new VectorOfPoint())
                {
                    area = CvInvoke.ContourArea(contour, false);
                }
            }*/
            int area = 0;
            for (int i = 0; i < imgOutput2.Rows; i++)
            {
                for (int j = 0; j < imgOutput2.Cols; j++)
                {
                    if (imgray.Data[i, j, 0] == 255)
                        area++;
                }
            }

            area1 = area * 0.1521;
            textBox1.Text = area1.ToString("f4");

            if (checkedListBox2.GetItemChecked(0))
            {
                CD_N_PU_TR.Add(area1);

                listBox12.Items.Add(area1.ToString("f4"));
            }
            if (checkedListBox2.GetItemChecked(1))
            {
                CD_N_PU_TL.Add(area1);

                listBox4.Items.Add(area1.ToString("f4"));
            }
            if (checkedListBox2.GetItemChecked(2))
            {
                OC_B.Add(area1);
                listBox20.Items.Add(area1.ToString("f4"));
            }

            if (checkedListBox2.GetItemChecked(3))
            {
                STN.Add(area1);
                listBox1.Items.Add(area1.ToString("f4"));
            }
        }

        private void button28_Click(object sender, EventArgs e)
        {
            VS = volume(VT, 5);
            double VSS = volume(VP, 5);
            VPP = VSS / VS * 100;
            double VPPS = 90 - VPP;
            textBox10.Text = VS.ToString("f4");
            textBox6.Text = VSS.ToString("f4");
            textBox9.Text = VPP.ToString("f4") + "%";
            textBox7.Text = VPPS.ToString("f4") + "%";
        }

        private static double volume(List<double> LD, double H)
        {

            double SV = 0;
            double V = 0;
            if (LD.Count == 0)
            {
                return 0;
            }
            if (LD.Count == 1)
            {
                LD.Add(0);
            }
            if (LD.Count == 2)
            {
                LD.Add(0);
            }

            for (int i = 1; i <= LD.Count - 1; i++)
            {

                double A = LD[i] + LD[i - 1];
                double DA = Math.Sqrt(LD[i] * LD[i - 1]);
                V = (A + DA) * H / 3;
                /* double k = (H * LD[LD.Count - 1]) / (LD[LD.Count - 2] - LD[LD.Count - 1]);
                  vk = (LD[LD.Count - 1] * k) / 3;
                  */
                SV = SV + V;
            }

            return SV;
        }

        private void button29_Click(object sender, EventArgs e)
        {
            CD_N_PU_TR.Clear();
            CD_N_PU_TL.Clear();
            OC_B.Clear();
            STN.Clear();
            VT.Clear();
            VP.Clear();
            listBox1.Items.Clear();
            listBox4.Items.Clear();
            listBox12.Items.Clear();
            listBox15.Items.Clear();
            listBox16.Items.Clear();
            listBox20.Items.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            //textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            //textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            //textBox11.Clear();
            //textBox12.Clear();
            textBox13.Clear();
            //textBox14.Clear();
            //textBox15.Clear();
            textBox16.Clear();
            //textBox17.Clear();
            //textBox18.Clear();
            //textBox19.Clear();
            textBox21.Clear();
            //textBox22.Clear();
            textBox25.Clear();
            textBox26.Clear();
            //textBox28.Clear();
            textBox35.Clear();
            textBox37.Clear();
            VTTR = 0;
            VTTL = 0;
            SUR_1 = 0;
            SUR_2 = 0;
            SUR_3 = 0;
            SUR_4 = 0;
            //SUR1 = 0;
            //SUR2 = 0;
            //SUR3 = 0;
            //VTTO = 0;
            //VTTT = 0;
            //VPTT = 0;
            //VPTT1 = 0;
            //VPTT2 = 0;
            //VPT1 = 0;
            //VPT2 = 0;
            //VPT0 = 0;
            test1 = 0;
            test2 = 0;
            test3 = 0;
            test4 = 0;
            test5 = 0;
            //test6 = 0;
            //test7 = 0;
            test8 = 0;
            test9 = 0;
            test10 = 0;
            test11 = 0;
            //test12 = 0;
            test66 = 0;
            ASI1 = 0;
            VPP = 0;
            VolCN = 0;
            VolPM = 0;
            VolOB = 0;
            VolSN = 0;
            //VPPCN = 0;
            //VPPPM = 0;
            //VPPOB = 0;
            //VPPSN = 0;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            for (int z = 0; z < CD_N_PU_TR.Count; z++)
            {
                SUR_1 = Convert.ToDouble(CD_N_PU_TR[z]); //SUR_1 += 等於讓這變數持續 + -x/
            }

            for (int z = 0; z < CD_N_PU_TL.Count; z++)
            {
                SUR_2 = Convert.ToDouble(CD_N_PU_TL[z]); //SUR_2+= 等於讓這變數持續+-x/ 
            }

            for (int z = 0; z < OC_B.Count; z++)
            {
                SUR_3 = Convert.ToDouble(OC_B[z]);      //SUR_3+= 等於讓這變數持續+-x/ 
            }

            test1 = ((SUR_1 - SUR_3) / SUR_3); //R區域攝取比值(對稱)
            test2 = ((SUR_2 - SUR_3) / SUR_3); //L區域攝取比值(同稱)  
            VTTR = SUR_1;                      //R區域面積(對稱同稱區域)
            VTTL = SUR_2;                      //L區域面積(同側區域)
            test4 = SUR_3;                      //OC區域面積(總合對稱同稱區域)
            test3 = VTTR + VTTL;                //R+L區域總面積(對稱+同稱)
            ASI1 = (2 * (test1 - test2) / (test1 + test2));

            for (int z = 0; z < VTS.Count; z++)
            {
                VS = Convert.ToDouble(VTS[z]); //全腦面積   VTS+= 等於讓這變數持續+-x/ 
            }


            //test5 = test1 / VS; //SUR1面積比
            //test6 = test2 / VS; //SUR2面積比

            test11 = ((test3 - test4) / test4);
            //test7  = test3 / VS * 100;  //SUR紋狀體面積比
            test9 = VTTR / VS * 100;   //R區域面積比
            test10 = VTTL / VS * 100;  //L區域面積比
            test8 = test4 / VS * 100;  //SUR0面積比

            // HY1 = test1;
            // HY2 = test2;

            //VPTT1 = 90 - VPT1;
            //VPTT2 = 90 - VPT2;
            //VPTT  = 90 - VPT0;

            textBox21.Text = test1.ToString("f4"); //R區域面積
            textBox5.Text = test2.ToString("f4"); //L區域面積
            textBox26.Text = test3.ToString("f4"); //R+L區域總面積
            textBox25.Text = test4.ToString("f4"); //OC區域面積
            textBox3.Text = test11.ToString("f4"); //Striatum攝取比值


            textBox35.Text = (test9 * 100).ToString("f4") + ("%"); //R區域面積比
            textBox16.Text = (test10 * 100).ToString("f4") + ("%"); //L區域面積比
            textBox37.Text = (test8 * 100).ToString("f4") + ("%"); //OC區域面積比
                                                                   //textBox38.Text = (test7*100).ToString("f4")+("%"); //R+L區域紋狀體比
            textBox13.Text = (ASI1 * 100).ToString("f4") + ("%"); //不稱性指標比

            /*textBox4.Text  = VPT1.ToString("f4")+("%"); //R區域體積比
            textBox8.Text  = VPT2.ToString("f4")+("%"); //L區域體積比
            textBox18.Text = VPT0.ToString("f4")+("%"); //OC區域體積比
            textBox13.Text = ASI1.ToString("f4")+("%"); //不稱性指標比*/

            /*textBox14.Text = VPTT1.ToString("f4") + ("%");
              textBox15.Text = VPTT2.ToString("f4") + ("%");
              textBox27.Text = VPTT.ToString("f4") + ("%"); */
        }

        private void button9_Click(object sender, EventArgs e)
        {
            double V = volume(CD_N_PU_TR, 5);
            VolCN = V / VS * 100;
            textBox4.Text = V.ToString("f4");
            textBox8.Text = (VolCN * 100).ToString("f4") + "%";

            double V1 = volume(CD_N_PU_TL, 5);
            VolPM = V1 / VS * 100;
            textBox11.Text = V1.ToString("f4");
            textBox14.Text = (VolPM * 100).ToString("f4") + "%";

            double V2 = volume(OC_B, 5);
            VolOB = V2 / VS * 100;
            textBox15.Text = V2.ToString("f4");
            textBox17.Text = (VolOB * 100).ToString("f4") + "%";

            /*for (int z = 0; z < STN.Count; z++)
            {
                SUR_4 = Convert.ToDouble(STN[z]); //SUR_2+= 等於讓這變數持續+-x/ 
            }
             test66 = SUR_4;
             test5 = SUR_4 / VS *100;
             textBox28.Text = test66.ToString("f4");
             textBox22.Text = (test5*100).ToString("f4") + "%";
             double V3 = volume(STN, 5);
             textBox18.Text = V3.ToString("f4");
             VolSN = V3 / VS * 100;
             textBox19.Text = (VolSN * 100).ToString("f4") + "%";*/
        }

        private void button13_Click(object sender, EventArgs e)
        {
            CD_N_PU_TR.Clear();
            CD_N_PU_TL.Clear();
            OC_B.Clear();
            STN.Clear();
            VT.Clear();
            VP.Clear();
            listBox1.Items.Clear();
            listBox4.Items.Clear();
            listBox12.Items.Clear();
            listBox15.Items.Clear();
            listBox16.Items.Clear();
            listBox20.Items.Clear();
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            //textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            //textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            //textBox11.Clear();
            //textBox12.Clear();
            textBox13.Clear();
            //textBox14.Clear();
            //textBox15.Clear();
            textBox16.Clear();
            //textBox17.Clear();
            //textBox18.Clear();
            //textBox19.Clear();
            textBox21.Clear();
            //textBox22.Clear();
            textBox25.Clear();
            textBox26.Clear();
            //textBox28.Clear();
            textBox35.Clear();
            textBox37.Clear();
            VTTR = 0;
            VTTL = 0;
            SUR_1 = 0;
            SUR_2 = 0;
            SUR_3 = 0;
            SUR_4 = 0;
            //SUR1 = 0;
            //SUR2 = 0;
            //SUR3 = 0;
            //VTTO = 0;
            //VTTT = 0;
            //VPTT = 0;
            //VPTT1 = 0;
            //VPTT2 = 0;
            //VPT1 = 0;
            //VPT2 = 0;
            //VPT0 = 0;
            test1 = 0;
            test2 = 0;
            test3 = 0;
            test4 = 0;
            test5 = 0;
            //test6 = 0;
            //test7 = 0;
            test8 = 0;
            test9 = 0;
            test10 = 0;
            test11 = 0;
            //test12 = 0;
            test66 = 0;
            ASI1 = 0;
            VPP = 0;
            VolCN = 0;
            VolPM = 0;
            VolOB = 0;
            //VolSN = 0;
            //VPPCN = 0;
            //VPPPM = 0;
            //VPPOB = 0;
            //VPPSN = 0;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            char[] Mychar = { '%' };

            test1 = (double.Parse(textBox21.Text.TrimEnd(Mychar))); //R區域吸收率
            test2 = (double.Parse(textBox5.Text.TrimEnd(Mychar)));  //L區域吸收率
            test9 = (double.Parse(textBox35.Text.TrimEnd(Mychar))); //R面積比
            test10 = (double.Parse(textBox16.Text.TrimEnd(Mychar))); //L面積比
            //test7 = (double.Parse(textBox38.Text.TrimEnd(Mychar))) ; //R+L面積比
            ASI1 = (double.Parse(textBox13.Text.TrimEnd(Mychar))); //不對稱性指標
            //VTTR  = (double.Parse(listBox12.Text.TrimEnd(Mychar))) / 100; //R區域總和
            //VTTL  = (double.Parse(listBox4.Text.TrimEnd(Mychar))) / 100;  //L區域總和
            //test4 = (double.Parse(listBox20.Text.TrimEnd(Mychar))) / 100; //OC區域總和
            test3 = (double.Parse(textBox26.Text.TrimEnd(Mychar))); //R+L區域總吸收率
            test8 = (double.Parse(textBox37.Text.TrimEnd(Mychar))); //OC面積比*/

            //double sum = (test1) + (test2) ;

            if (test1 > 1.4 || test1 == 2 && test2 > 1.7 && test2 == 2.2)
            {
                textBox2.Text = "0.0";
            }
            else if (test1 > 0.9 || test1 == 0.58 && test2 > 0.42 && test2 == 1.2)
            {
                textBox2.Text = "0.5";
            }
            else if (test1 > 0.45 || test1 == 0.58 && test2 > 0.42 && test2 == 0.66)
            {
                textBox2.Text = "1.0";
            }
            else if (test1 > 0.3 || test1 == 0.55 && test2 > 0.3 || test2 == 0.5)
            {
                textBox2.Text = "2.0";
            }
            else if (test1 > 0.2 || test1 > 0.1 || test1 == 0.298 && test2 > 0.2 || test2 < 0.1 || test2 == 0.315)

            {
                textBox2.Text = "3.0";
            }
        }

        private void button25_Click(object sender, EventArgs e)
        {
            for (int z = 0; z < STN.Count; z++)
            {
                SUR_4 = Convert.ToDouble(STN[z]); //SUR_2+= 等於讓這變數持續+-x/ 
            }
            test66 = SUR_4;
            test5 = SUR_4 / VS * 100;
            textBox28.Text = test66.ToString("f4");
            textBox22.Text = (test5 * 100).ToString("f4") + "%";
            double V3 = volume(STN, 5);
            textBox18.Text = V3.ToString("f4");
            VolSN = V3 / VS * 100;
            textBox19.Text = (VolSN * 100).ToString("f4") + "%";
        }

        private void button24_Click(object sender, EventArgs e)
        {
            num1++;
            count++;
            string Data = textBox20.Text.ToString();

            string filestr = "D:\\PD患者分期數據\\TEST" + Data;
            Excel.Application Excel_Data1 = new Excel.Application(); //設定Excel 應用程序
            Excel.Workbook Excel_Wb = Excel_Data1.Workbooks.Open(filestr);
            Excel.Worksheet Excel_Ws1 = new Excel.Worksheet();
            Excel.Worksheet Excel_Ws2 = new Excel.Worksheet();
            Excel.Worksheet Excel_Ws3 = new Excel.Worksheet();
            Excel_Ws1 = Excel_Wb.Worksheets[1];
            Excel_Ws2 = Excel_Wb.Worksheets[2];
            Excel_Ws3 = Excel_Wb.Worksheets[3];

            //Excel_Ws1.Activate();
            Excel_Data1.Cells[count, 1] = num1;
            Excel_Data1.Cells[count, 2] = textBox10.Text;
            Excel_Data1.Cells[count, 3] = textBox6.Text;
            Excel_Data1.Cells[count, 4] = textBox9.Text;
            Excel_Data1.Cells[count, 5] = textBox7.Text;
            Excel_Data1.Cells[count, 6] = textBox21.Text;
            Excel_Data1.Cells[count, 7] = textBox35.Text;
            Excel_Data1.Cells[count, 8] = textBox5.Text;
            Excel_Data1.Cells[count, 9] = textBox16.Text;
            Excel_Data1.Cells[count, 10] = textBox25.Text;
            Excel_Data1.Cells[count, 11] = textBox37.Text;
            //Excel_Data1.Cells[count, 12] = textBox28.Text;
            //Excel_Data1.Cells[count, 13] = textBox22.Text;
            //Excel_Data1.Cells[count, 14] = textBox4.Text;
            //Excel_Data1.Cells[count, 15] = textBox8.Text;
            //Excel_Data1.Cells[count, 16] = textBox11.Text;
            //Excel_Data1.Cells[count, 17] = textBox14.Text;
            //Excel_Data1.Cells[count, 18] = textBox15.Text;
            //Excel_Data1.Cells[count, 19] = textBox17.Text;
            //Excel_Data1.Cells[count, 20] = textBox18.Text;
            //Excel_Data1.Cells[count, 21] = textBox19.Text;
            Excel_Data1.Cells[count, 12] = textBox26.Text;
            Excel_Data1.Cells[count, 13] = textBox3.Text;
            Excel_Data1.Cells[count, 14] = textBox13.Text;
            Excel_Data1.Cells[count, 15] = textBox2.Text;

            //Excel_Ws2.Activate();
            Excel_Data1.Cells[count, 1] = num1;
            Excel_Data1.Cells[count, 2] = textBox10.Text;
            Excel_Data1.Cells[count, 3] = textBox6.Text;
            Excel_Data1.Cells[count, 4] = textBox9.Text;
            Excel_Data1.Cells[count, 5] = textBox7.Text;
            Excel_Data1.Cells[count, 6] = textBox21.Text;
            Excel_Data1.Cells[count, 7] = textBox35.Text;
            Excel_Data1.Cells[count, 8] = textBox5.Text;
            Excel_Data1.Cells[count, 9] = textBox16.Text;
            Excel_Data1.Cells[count, 10] = textBox25.Text;
            Excel_Data1.Cells[count, 11] = textBox37.Text;
            //Excel_Data1.Cells[count, 12] = textBox28.Text;
            //Excel_Data1.Cells[count, 13] = textBox22.Text;
            //Excel_Data1.Cells[count, 14] = textBox4.Text;
            //Excel_Data1.Cells[count, 15] = textBox8.Text;
            //Excel_Data1.Cells[count, 16] = textBox11.Text;
            //Excel_Data1.Cells[count, 17] = textBox14.Text;
            //Excel_Data1.Cells[count, 18] = textBox15.Text;
            //Excel_Data1.Cells[count, 19] = textBox17.Text;
            //Excel_Data1.Cells[count, 20] = textBox18.Text;
            //Excel_Data1.Cells[count, 21] = textBox19.Text;
            Excel_Data1.Cells[count, 12] = textBox26.Text;
            Excel_Data1.Cells[count, 13] = textBox3.Text;
            Excel_Data1.Cells[count, 14] = textBox13.Text;
            Excel_Data1.Cells[count, 15] = textBox2.Text;

            //Excel_Ws3.Activate();
            Excel_Data1.Cells[count, 1] = num1;
            Excel_Data1.Cells[count, 2] = textBox10.Text;
            Excel_Data1.Cells[count, 3] = textBox6.Text;
            Excel_Data1.Cells[count, 4] = textBox9.Text;
            Excel_Data1.Cells[count, 5] = textBox7.Text;
            Excel_Data1.Cells[count, 6] = textBox21.Text;
            Excel_Data1.Cells[count, 7] = textBox35.Text;
            Excel_Data1.Cells[count, 8] = textBox5.Text;
            Excel_Data1.Cells[count, 9] = textBox16.Text;
            Excel_Data1.Cells[count, 10] = textBox25.Text;
            Excel_Data1.Cells[count, 11] = textBox37.Text;
            //Excel_Data1.Cells[count, 12] = textBox28.Text;
            //Excel_Data1.Cells[count, 13] = textBox22.Text;
            //Excel_Data1.Cells[count, 14] = textBox4.Text;
            //Excel_Data1.Cells[count, 15] = textBox8.Text;
            //Excel_Data1.Cells[count, 16] = textBox11.Text;
            //Excel_Data1.Cells[count, 17] = textBox14.Text;
            //Excel_Data1.Cells[count, 18] = textBox15.Text;
            //Excel_Data1.Cells[count, 19] = textBox17.Text;
            //Excel_Data1.Cells[count, 20] = textBox18.Text;
            //Excel_Data1.Cells[count, 21] = textBox19.Text;
            Excel_Data1.Cells[count, 12] = textBox26.Text;
            Excel_Data1.Cells[count, 13] = textBox3.Text;
            Excel_Data1.Cells[count, 14] = textBox13.Text;
            Excel_Data1.Cells[count, 15] = textBox2.Text;

            Excel_Wb.Save();
            Excel_Ws1 = null;
            Excel_Wb.Close();
            Excel_Wb = null;
            Excel_Data1.Quit();
            Excel_Data1 = null;
            label33.Text = num1.ToString();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            string Data = textBox20.Text.ToString();

            string filestr = "D:\\PD患者分期數據\\TEST" + Data;
            Excel.Application Excel_Data1 = new Excel.Application(); //設定Excel 應用程序
            Excel.Workbook Excel_Wb = Excel_Data1.Workbooks.Add();
            Excel.Worksheet Excel_Ws1 = new Excel.Worksheet();
            Excel.Worksheet Excel_Ws2 = new Excel.Worksheet();
            Excel.Worksheet Excel_Ws3 = new Excel.Worksheet();
            Excel_Ws1 = Excel_Wb.Worksheets[1];
            Excel_Ws1.Name = "TRODAT個腦資訊";
            Excel_Ws2 = Excel_Wb.Worksheets.Add();
            Excel_Ws2.Name = "CT個腦資訊";
            Excel_Ws3 = Excel_Wb.Worksheets.Add();
            Excel_Ws3.Name = "MRI個腦資訊";

            Excel_Data1.Cells[1, 1] = "編號";
            Excel_Data1.Cells[1, 2] = "全腦體積";
            Excel_Data1.Cells[1, 3] = "腦組織體積";
            Excel_Data1.Cells[1, 4] = "腦組織比例";
            Excel_Data1.Cells[1, 5] = "萎縮比";
            Excel_Data1.Cells[1, 6] = "Caudate Nucleus  Putamen(R)比值";
            Excel_Data1.Cells[1, 7] = "%"; //R面積比
            Excel_Data1.Cells[1, 8] = "Caudate Nucleus  Putamen(L)比值";
            Excel_Data1.Cells[1, 9] = "%"; //L面積比
            Excel_Data1.Cells[1, 10] = "Occipital Bone";
            Excel_Data1.Cells[1, 11] = "%";//OC面積比 
            //Excel_Data1.Cells[1, 12] = "Substantia nigra(SN)";
            //Excel_Data1.Cells[1, 13] = "%";//SN面積比
            //Excel_Data1.Cells[1, 14] = "Caudate Nucleus  Putamen(R)體積";
            //Excel_Data1.Cells[1, 15] = "%";//R體積比
            //Excel_Data1.Cells[1, 16] = "Caudate Nucleus  Putamen(L)體積";
            //Excel_Data1.Cells[1, 17] = "%";//L體積比
            //Excel_Data1.Cells[1, 18] = "Occipital Bone體積";
            //Excel_Data1.Cells[1, 19] = "%";//OC體積比
            //Excel_Data1.Cells[1, 20] = "Substantia nigra(SN)體積";
            //Excel_Data1.Cells[1, 21] = "%";//SN體積比
            Excel_Data1.Cells[1, 12] = "紋狀體總面積";
            Excel_Data1.Cells[1, 13] = "紋狀體攝取值";
            Excel_Data1.Cells[1, 14] = "不對稱性指標";
            Excel_Data1.Cells[1, 15] = "系統HY";

            Clipboard.SetDataObject(imgSelect.Image, false);
            Excel_Data1.Cells[3, 1].PasteSpecial("Bitmap");

            Excel_Wb.SaveAs(filestr);

            Excel_Ws1 = null;
            Excel_Wb.Close();
            Excel_Wb = null;
            Excel_Data1.Quit();
            Excel_Data1 = null;
            num1 = 0;
            label33.Text = num1.ToString();
        }
    }
}
