﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _Emgu_integrate
{
    public class StringNum : IComparable<StringNum>
    {
        private List<string> _strings;
        private List<int> _numbers;

        public StringNum(string value)
        {
            _strings = new List<string>();
            _numbers = new List<int>();
            int pos = 0;
            bool number = false;
            while (pos < value.Length)
            {
                int len = 0;
                while (pos + len < value.Length && char.IsDigit(value[pos + len]) == number)
                {
                    len++;
                }
                if (number)
                {
                    _numbers.Add(int.Parse(value.Substring(pos, len)));
                }
                else
                {
                    _strings.Add(value.Substring(pos, len));
                }
                pos += len;
                number = !number;
            }
        }

        public int CompareTo(StringNum other)
        {
            int index = 0;
            while (index < _strings.Count && index < other._strings.Count)
            {
                int result = _strings[index].CompareTo(other._strings[index]);
                if (result != 0) return result;
                if (index < _numbers.Count && index < other._numbers.Count)
                {
                    result = _numbers[index].CompareTo(other._numbers[index]);
                    if (result != 0) return result;
                }
                else
                {
                    return index == _numbers.Count && index == other._numbers.Count ? 0 : index == _numbers.Count ? -1 : 1;
                }
                index++;
            }
            return index == _strings.Count && index == other._strings.Count ? 0 : index == _strings.Count ? -1 : 1;
        }
    }
}
